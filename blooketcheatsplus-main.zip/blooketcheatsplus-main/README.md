<h2 align="center">Cheats made by people who actaully know what they're doing</h2>
<h1 align="center">scroll down for more information 🠗</h1>
<h2 align="center">How to use:</h2>

<h3 align="center">if the hacks dont work update them (only if your code doesnt have a jsdelivr link because that is always up to date) and if it IS updated and wont work make an issue in the <a href="https://discord.gg/8A6J234n7v">Discord Server</a></h2>
<h3 align="center"><a href="https://github.com/Blooket-Council/Blooket-Cheats">Original Official Blooket Cheats</a></h2>
<h3 align="center">randomstuff69 is the real account on greasy fork</h2>


<h2 align="center">how to use the userscript:</h2>
<h2 align="center">click <a href="https://github.com/randomstuff69/blooketcheatsplus/raw/refs/heads/main/GUI/Gui.user.js" font-family="Source Code Pro">this link </a>and it should prompt your userscript manager to download</h2>


## FAQ


<details><summary><h3>What's the difference between BCP and the original cheats?</h3></summary>

New and fixed features are in BCP to give you a better experience and an advantage to people who have the orignal gui. Making this better.
</details>

<details><summary><h3>What can I do if JavaScript is blocked?</h3></summary>

Try <a href="https://blooketbot.glitch.me/">https://blooketbot.glitch.me/</a>
</details>


<details><summary><h3>Which script should I use to make a bookmarklet?</h3></summary>

link.html if you dragged it into the bookmark bar, if you didnt You should use the scripts ending in ".min.js", as using the others will have errors due to formatting.
</details>

<details><summary><h3>Can you give me infinite tokens / bypass daily limit / permanently give me blooks / change pack luck?</h3></summary>

No, these are things we would've already done if they were possible, they're managed on the backend of Blooket so we can't modify them
</details>

<details><summary><h3>Can you make hacks for (game)</h3></summary>

no
</details>

<details><summary><h3>Can you make more Battle Royale cheats</h3></summary>

Battle Royale is a gamemode that works almost entirely on the host's end. The only thing we have control over is answering questions.
</details>

<details><summary><h3>What's the difference between Chat and Lobbychat?</h3></summary>

Chat (By Yeahbread on Ego Menu) is an online chat that you can talk and send images to anyone, even if they're not on the same game. Lobbychat (by Cryptodude3) can chat with anyone if they're in the same game as you. You can talk to BlooketBot users with Lobbychat as well. Aside from chatting Lobbychat can also execute commands. Here is a list:

### Commands
* set gold: /setstate gold:val
* set crypto /setstate crypto:val
* list all values to set: /dumpstate
* freeze frenzy scoreboard: /setval f/t t
* crash gold: /setval g/t t
* crash crypto: /setval cr/t t
* crash dino: /setval f/t t
* crash pirate: /setval d/t t
* freeze gold scoreboard: /setval tat/t t
* crash defense2(may take a few tries): /setval d/t t
* crash monster brawl: /setval xp/t t
* set gold to inf: /setval g Infinity
* just do /help for the rest
## Run while in lobby or in game, not before, not on nickname screen, INGAME!
</details>


<details><summary><h3>What happend to Minesraft2?</h3></summary>

Minesraft2 was sent a cease and desist from Blooket, and 05konz offered to take over since he wouldn't be able to.
</details>

<details><summary><h3>How do I do this on mobile?</h3></summary>

These scripts aren't made for mobile, so we don't really know how to get them to work on it.
</details>

<details><summary><h3>What's the Mobile GUI?</h3></summary>

The mobile GUI is the first GUI Minesraft2 ever made. Some people said it worked on mobile and it's a lot neater for mobile use apparently so we just called it that.
</details>

<details><summary><h3>Other Cheats</h3></summary>

* Blooket Bot: https://blooketbot.glitch.me/
* Blooket Bot Vercel: https://blooketbot.vercel.app/
* Homework editor (probably down): https://blookethwk.glitch.me/

</details>

<details><summary><h2>List of Cheats</h2></summary>

* [GUI](GUI/Gui.js)
* [Mobile GUI](MobileGUI/mobileGui.js)
### Monster Brawl Fixed by <a href="https://github.com/cryptodude3">Cryptodude3</a> aka Ducklife3141
* Double Enemy XP
* Half Enemy Speed
* Instant Kill
* Invincibility
* Kill Enemies
* Magnet
* Max Current Abilities
* Next Level
* Remove Obstacles
* Reset Health
* Set XP
* Set Level
### Cafe
* Max Items
* Remove Customers
* Reset Abilities
* Set Cash
* Stock Food
* Attack Player  By <a href="https://github.com/cryptodude3">Cryptodude3</a> aka Ducklife3141
* Spam Attack Player  By <a href="https://github.com/cryptodude3">Cryptodude3</a> aka Ducklife3141
### Crypto Hack
* Always Triple
* Always Hack By <a href="https://github.com/dannydan0167">DannyDan0167</a> aka me
* Auto Guess Fixed By <a href="https://github.com/dannydan0167">DannyDan0167</a> aka me
* Choice ESP 
* Password ESP Fixed By <a href="https://github.com/dannydan0167">DannyDan0167</a> aka me
* Remove Hack
* Set Crypto
* Set Password
* Crash Password Added By <a href="https://github.com/cryptodude3">Cryptodude3</a> aka Ducklife3141
* Steal Players Crypto
### Deceptive Dinos
* Auto Choose
* Rock ESP
* Set Fossils
* Set Multiplier
* Stop Cheating
### Tower of Doom
* Fill Deck
* Max Cards
* Max Health
* Max Stats
* Min Enemy
* Set Coins
### Factory
* Choose Blook
* Free Upgrades
* Max Blooks
* Remove Glitches
* Send Glitch
* Set All Mega Bot
* Set Cash
### Fishing Frenzy
* Frenzy
* Remove Distraction
* Send Distraction
* Set Lure
* Set Weight
### Flappy Blook
* Set Score
* Toggle Ghost
### Global
* Auto Answer
* Change Blook Ingame
* Every Answer Correct
* Flood Game Fixed by <a href="https://github.com/cryptodude3">Cryptodude3</a> aka Ducklife3141
* Get Daily Rewards
* Highlight Answers
* Host Any Gamemode
* Remove Name Limit
* Remove Random Name
* Sell Cheap Duplicates
* Sell Duplicate Blooks
* Simulate Pack
* Simulate Unlock
* Spam Buy Blooks
* Subtle Highlight Answers
* Use Any Blook Fixed by <a href="https://github.com/cryptodude3">Cryptodude3</a> aka Ducklife3141
* Use Any Banner By <a href="https://github.com/cryptodude3">Cryptodude3</a> aka Ducklife3141
* Crash Game By <a href="https://github.com/cryptodude3">Cryptodude3</a> aka Ducklife3141
* Chat By <a href="https://github.com/yeahbread/Ego-Menu-Bookmarklets">Ego Menu</a>
* Lobbychat By <a href="https://github.com/cryptodude3">Cryptodude3</a> aka Ducklife3141
* Freeze Leaderboard By <a href="https://github.com/cryptodude3">Cryptodude3</a> aka Ducklife3141
* Pin Guesser By <a href="https://github.com/cryptodude3">Cryptodude3</a> aka Ducklife3141
* Bypass Filter By <a href="https://github.com/cryptodude3">Cryptodude3</a> aka Ducklife3141
* Use Banner IDs By <a href="https://github.com/cryptodude3">Cryptodude3</a> aka Ducklife3141
#### Intervals
* Auto Answer
* Highlight Answers
* Percent Auto Answer
* Subtle Highlight Answers
### Gold Quest
* Always Triple
* Auto Choose
* Chest ESP Fixed By <a href="https://github.com/dannydan0167">DannyDan0167</a> aka me
* Remove lose 25%-50% By <a href="https://github.com/dannydan0167">DannyDan0167</a> aka me
* Reset All Gold
* Reset Players Gold
* Set Gold
* Swap Gold
### Crazy Kingdom
* Choice ESP Fixed By <a href="https://github.com/dannydan0167">DannyDan0167</a> aka me
* Choice ESP Loop
* Disable Toucan
* Max Stats
* Set Guests
* Skip Guest
### Racing
* Instant Win
### Battle Royale
* Auto Answer
#### Intervals
* Auto Answer
### Blook Rush
* Set Blooks
* Set Defense
### Tower Defense
* Earthquake
* Max Towers
* Remove Ducks
* Remove Enemies
* Remove Obsticles
* Set Damage
* Set Round
* Set Tokens
### Tower Defense 2
* Max Towers
* Remove Enemies
* Set Coins
* Set Health
* Set Round
### Pirate's Voyage
* Max Levels
* Set Doubloons
* Start Heist
* Swap Doubloons
* Take Doubloons
### Santa's Workshop
* Remove Distractions
* Send Distraction
* Set Toys
* Set Toys Per Question
* Swap Toys
</details>
[![Star History Chart](https://api.star-history.com/svg?repos=randomstuff69/blooketcheatsplus&type=Date)](https://star-history.com/#randomstuff69/blooketcheatsplus&Date)


[![Hits](https://hits.sh/github.com/DannyDan0167/Blooket-Cheats-Plus.svg)](https://hits.sh/github.com/DannyDan0167/Blooket-Cheats-Plus/)
