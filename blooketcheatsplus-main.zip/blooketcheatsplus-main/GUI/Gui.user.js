// ==UserScript==
// @name         Blooket Cheats Plus
// @namespace    https://github.com/randomstuff69/blooketcheatsplus
// @version      15
// @description  Blooket Cheats Plus
// @updateURL    https://raw.githubusercontent.com/randomstuff69/blooketcheatsplus/main/Update/Gui.meta.js
// @downloadURL  https://raw.githubusercontent.com/randomstuff69/blooketcheatsplus/main/GUI/Gui.user.js
// @author       DannyDan0167 and Cool Duck
// @match        *://*.blooket.com/*
// @icon         https://i.ibb.co/sWqBm0K/1024.png
// @grant        none
// @require     https://raw.githubusercontent.com/randomstuff69/blooketcheatsplus/refs/heads/main/GUI/Gui.js
// ==/UserScript==
